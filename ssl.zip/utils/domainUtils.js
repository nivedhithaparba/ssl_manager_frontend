function validateDomain(domain) {
    if (!domain || typeof domain !== 'string') return false;
    
    const domainRegex = /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
    const cleanDomain = domain.trim().toLowerCase();
    
    if (cleanDomain.length === 0 || cleanDomain.length > 255) return false;
    if (cleanDomain.startsWith('.') || cleanDomain.endsWith('.')) return false;
    if (cleanDomain.includes('..')) return false;
    
    return domainRegex.test(cleanDomain);
}

function getDaysUntilExpiry(expiryDate) {
    const expiry = new Date(expiryDate);
    const now = new Date();
    const diffTime = expiry - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
}

function generateExpiryDate() {
    const date = new Date();
    date.setDate(date.getDate() + 90); // SSL certificates typically valid for 90 days
    return date.toISOString();
}

function formatDomainForStorage(domain) {
    return domain.trim().toLowerCase();
}
