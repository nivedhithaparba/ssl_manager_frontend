async function generateSSLCertificate(domain) {
    try {
        const formattedDomain = formatDomainForStorage(domain);
        
        // Check if domain already exists
        const existingDomains = await trickleListObjects('ssl-domain', 100, true);
        const domainExists = existingDomains.items.some(
            item => item.objectData.domain === formattedDomain
        );
        
        if (domainExists) {
            throw new Error('SSL certificate already exists for this domain');
        }
        
        // Create new SSL certificate record
        const sslData = {
            domain: formattedDomain,
            issueDate: new Date().toISOString(),
            expiryDate: generateExpiryDate(),
            status: 'active',
            autoRenew: false
        };
        
        const result = await trickleCreateObject('ssl-domain', sslData);
        return result;
    } catch (error) {
        console.error('SSL generation error:', error);
        throw error;
    }
}

async function loadSSLDomains() {
    try {
        const result = await trickleListObjects('ssl-domain', 100, true);
        return result.items || [];
    } catch (error) {
        console.error('Load domains error:', error);
        return [];
    }
}

async function renewSSLCertificate(domain) {
    try {
        const updatedData = {
            ...domain.objectData,
            issueDate: new Date().toISOString(),
            expiryDate: generateExpiryDate(),
            status: 'active'
        };
        
        return await trickleUpdateObject('ssl-domain', domain.objectId, updatedData);
    } catch (error) {
        console.error('SSL renewal error:', error);
        throw error;
    }
}

async function toggleAutoRenew(domain) {
    try {
        const updatedData = {
            ...domain.objectData,
            autoRenew: !domain.objectData.autoRenew
        };
        
        return await trickleUpdateObject('ssl-domain', domain.objectId, updatedData);
    } catch (error) {
        console.error('Auto-renew toggle error:', error);
        throw error;
    }
}
