const API_BASE = 'https://api.ssl-dashboard.com/v1';

const apiClient = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor for auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    console.log('API Request:', config.method.toUpperCase(), config.url, config.data);
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => {
    console.log('API Response:', response.status, response.data);
    return response;
  },
  (error) => {
    console.error('API Error:', error.response?.status, error.response?.data);
    if (error.response?.status === 401) {
      localStorage.removeItem('authToken');
      localStorage.removeItem('currentUser');
      window.location.reload();
    }
    return Promise.reject(error);
  }
);

const apiService = {
  // Authentication APIs
  async login(credentials) {
    try {
      const response = await apiClient.post('/auth/login', {
        username: credentials.username,
        password: credentials.password
      });
      return {
        success: true,
        data: response.data,
        token: response.data.token,
        user: response.data.user
      };
    } catch (error) {
      // Fallback to demo users for development
      const demoUser = defaultUsers.find(u => 
        u.username === credentials.username && u.password === credentials.password
      );
      if (demoUser) {
        return {
          success: true,
          data: { user: demoUser, token: 'demo-token-' + Date.now() },
          token: 'demo-token-' + Date.now(),
          user: demoUser
        };
      }
      throw new Error('Invalid credentials');
    }
  },

  async logout() {
    try {
      await apiClient.post('/auth/logout');
      return { success: true, message: 'Logged out successfully' };
    } catch (error) {
      return { success: true, message: 'Logged out locally' };
    }
  },

  // SSL Certificate APIs
  async getCertificates() {
    try {
      const response = await apiClient.get('/certificates');
      return { success: true, data: response.data.certificates };
    } catch (error) {
      // Fallback to Trickle database
      const result = await window.trickleListObjects('ssl-certificate', 100, true);
      return { success: true, data: result.items || [] };
    }
  },

  async generateCertificate(domain) {
    try {
      const response = await apiClient.post('/certificates', { domain });
      return { success: true, data: response.data.certificate };
    } catch (error) {
      // Fallback to Trickle database
      const certificateData = {
        domain,
        issueDate: new Date().toISOString(),
        expiryDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
        autoRenew: false,
        status: 'active'
      };
      const result = await window.trickleCreateObject('ssl-certificate', certificateData);
      return { success: true, data: result };
    }
  },

  async renewCertificate(certificateId) {
    try {
      const response = await apiClient.post(`/certificates/${certificateId}/renew`);
      return { success: true, data: response.data.certificate };
    } catch (error) {
      throw new Error('Failed to renew certificate');
    }
  },

  async toggleAutoRenew(certificateId, autoRenew) {
    try {
      const response = await apiClient.patch(`/certificates/${certificateId}`, { autoRenew });
      return { success: true, data: response.data.certificate };
    } catch (error) {
      throw new Error('Failed to update auto-renewal');
    }
  },

  async deleteCertificate(certificateId) {
    try {
      await apiClient.delete(`/certificates/${certificateId}`);
      return { success: true, message: 'Certificate deleted successfully' };
    } catch (error) {
      throw new Error('Failed to delete certificate');
    }
  },

  // User Management APIs
  async getUsers() {
    try {
      const response = await apiClient.get('/users');
      return { success: true, data: response.data.users };
    } catch (error) {
      // Fallback to Trickle database
      const result = await window.trickleListObjects('user', 100, true);
      const users = result.items?.map(item => ({ id: item.objectId, ...item.objectData })) || defaultUsers;
      return { success: true, data: users };
    }
  },

  async createUser(userData) {
    try {
      const response = await apiClient.post('/users', userData);
      return { success: true, data: response.data.user };
    } catch (error) {
      // Fallback to Trickle database
      const result = await window.trickleCreateObject('user', userData);
      return { success: true, data: { id: result.objectId, ...userData } };
    }
  },

  async updateUser(userId, userData) {
    try {
      const response = await apiClient.put(`/users/${userId}`, userData);
      return { success: true, data: response.data.user };
    } catch (error) {
      // Fallback to Trickle database
      await window.trickleUpdateObject('user', userId, userData);
      return { success: true, data: { id: userId, ...userData } };
    }
  },

  async deleteUser(userId) {
    try {
      await apiClient.delete(`/users/${userId}`);
      return { success: true, message: 'User deleted successfully' };
    } catch (error) {
      // Fallback to Trickle database
      await window.trickleDeleteObject('user', userId);
      return { success: true, message: 'User deleted successfully' };
    }
  },

  async resetPassword(userId, newPassword) {
    try {
      const response = await apiClient.patch(`/users/${userId}/password`, { password: newPassword });
      return { success: true, message: 'Password updated successfully' };
    } catch (error) {
      throw new Error('Failed to update password');
    }
  }
};
