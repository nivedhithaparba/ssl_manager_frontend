function Modal({ isOpen, onClose, children, title }) {
  try {
    React.useEffect(() => {
      lucide.createIcons();
    }, []);

    if (!isOpen) return null;

    return (
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 fade-in"
        onClick={onClose}
      >
        <div 
          className="bg-white rounded-2xl shadow-2xl max-w-lg w-full mx-4 bounce-in"
          onClick={(e) => e.stopPropagation()}
        >
          {title && (
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <i data-lucide="x" className="w-5 h-5"></i>
              </button>
            </div>
          )}
          <div className="p-6">
            {children}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Modal component error:', error);
    reportError(error);
  }
}
