function UserManagement({ user, onToast }) {
    try {
        const [users, setUsers] = React.useState([]);
        const [showUserForm, setShowUserForm] = React.useState(false);
        const [editingUser, setEditingUser] = React.useState(null);

        React.useEffect(() => {
            loadUsers();
        }, []);

        const loadUsers = async () => {
            try {
                console.log('Loading users...');
                const response = await apiService.getUsers();
                
                console.log('Users Response:', response);
                
                if (response.success) {
                    setUsers(response.data);
                } else {
                    throw new Error('Failed to load users');
                }
            } catch (error) {
                console.error('Load users error:', error);
                setUsers(defaultUsers);
                onToast('Using demo users', 'info');
            }
        };

        const handleUserSubmit = async (userData) => {
            try {
                console.log('User Submit Request:', { userData, editing: !!editingUser });
                
                let response;
                if (editingUser) {
                    response = await apiService.updateUser(editingUser.id, userData);
                    onToast('User updated successfully', 'success');
                } else {
                    response = await apiService.createUser(userData);
                    onToast('User created successfully', 'success');
                }
                
                console.log('User Submit Response:', response);
                
                await loadUsers();
                setShowUserForm(false);
                setEditingUser(null);
            } catch (error) {
                console.error('User submit error:', error);
                onToast('Failed to save user', 'error');
            }
        };

        const handleDeleteUser = async (userToDelete) => {
            if (window.confirm(`Delete user ${userToDelete.name}?`)) {
                try {
                    console.log('Delete User Request:', { userId: userToDelete.id });
                    
                    const response = await apiService.deleteUser(userToDelete.id);
                    
                    console.log('Delete User Response:', response);
                    
                    if (response.success) {
                        onToast('User deleted successfully', 'success');
                        await loadUsers();
                    } else {
                        throw new Error('Failed to delete user');
                    }
                } catch (error) {
                    console.error('Delete user error:', error);
                    onToast('Failed to delete user', 'error');
                }
            }
        };

        const handlePasswordReset = async (userToReset) => {
            const newPassword = window.prompt(`Enter new password for ${userToReset.name}:`);
            if (newPassword) {
                try {
                    console.log('Reset Password Request:', { userId: userToReset.id });
                    
                    const response = await apiService.resetPassword(userToReset.id, newPassword);
                    
                    console.log('Reset Password Response:', response);
                    
                    if (response.success) {
                        onToast('Password updated successfully', 'success');
                    } else {
                        throw new Error('Failed to update password');
                    }
                } catch (error) {
                    console.error('Password reset error:', error);
                    onToast('Failed to update password', 'error');
                }
            }
        };

        return (
            <div>
                {React.createElement(UserList, {
                    users: users,
                    currentUser: user,
                    onAdd: () => { setEditingUser(null); setShowUserForm(true); },
                    onEdit: (userToEdit) => { setEditingUser(userToEdit); setShowUserForm(true); },
                    onDelete: handleDeleteUser,
                    onPasswordReset: handlePasswordReset
                })}

                {React.createElement(Modal, { 
                    isOpen: showUserForm, 
                    onClose: () => setShowUserForm(false) 
                }, React.createElement(UserForm, {
                    user: editingUser,
                    onSubmit: handleUserSubmit,
                    onClose: () => setShowUserForm(false)
                }))}
            </div>
        );
    } catch (error) {
        console.error('UserManagement component error:', error);
        reportError(error);
    }
}
