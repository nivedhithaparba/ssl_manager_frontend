function Toast({ message, type, onClose }) {
  try {
    React.useEffect(() => {
      lucide.createIcons();
      if (message) {
        const timer = setTimeout(onClose, 4000);
        return () => clearTimeout(timer);
      }
    }, [message, onClose]);

    if (!message) return null;

    const typeConfig = {
      success: { 
        bg: 'bg-green-50 border-green-200', 
        text: 'text-green-800', 
        icon: 'check-circle' 
      },
      error: { 
        bg: 'bg-red-50 border-red-200', 
        text: 'text-red-800', 
        icon: 'x-circle' 
      },
      info: { 
        bg: 'bg-blue-50 border-blue-200', 
        text: 'text-blue-800', 
        icon: 'info' 
      }
    };

    const config = typeConfig[type] || typeConfig.info;

    return (
      <div className={`fixed top-4 right-4 ${config.bg} ${config.text} border rounded-lg p-4 bounce-in flex items-center space-x-3 shadow-lg z-50 max-w-sm`}>
        <i data-lucide={config.icon} className="w-5 h-5 flex-shrink-0"></i>
        <span className="font-medium flex-1">{message}</span>
        <button 
          onClick={onClose} 
          className="flex-shrink-0 hover:opacity-70 transition-opacity"
        >
          <i data-lucide="x" className="w-4 h-4"></i>
        </button>
      </div>
    );
  } catch (error) {
    console.error('Toast component error:', error);
    reportError(error);
  }
}
