function DomainTable({ domains, onAction }) {
    try {
        React.useEffect(() => {
            lucide.createIcons();
        }, [domains]);

        const getStatusBadge = (expiryDate, autoRenew) => {
            const days = getDaysUntilExpiry(expiryDate);
            if (days <= 7) return { text: 'Critical', class: 'bg-red-100 text-red-800 border-red-200' };
            if (days <= 30) return { text: 'Expiring Soon', class: 'bg-yellow-100 text-yellow-800 border-yellow-200' };
            return { text: autoRenew ? 'Auto-Renew' : 'Valid', class: autoRenew ? 'bg-purple-100 text-purple-800 border-purple-200' : 'bg-green-100 text-green-800 border-green-200' };
        };

        if (domains.length === 0) {
            return (
                <div className="glass-effect rounded-2xl p-12 text-center card-glow slide-in-up"
                    data-name="empty-state"
                    data-file="components/DomainTable.js"
                >
                    <div className="bg-gray-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i data-lucide="shield-off" className="w-10 h-10 text-gray-400"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No SSL Certificates</h3>
                    <p className="text-gray-600">Generate your first SSL certificate to get started.</p>
                </div>
            );
        }

        return (
            <div className="glass-effect rounded-2xl overflow-hidden card-glow slide-in-up"
                data-name="domain-table"
                data-file="components/DomainTable.js"
            >
                <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-6 py-4 border-b">
                    <h3 className="text-xl font-semibold text-gray-900 flex items-center">
                        <i data-lucide="database" className="w-5 h-5 mr-2"></i>
                        SSL Certificates ({domains.length})
                    </h3>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Domain</th>
                                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Expires</th>
                                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {domains.map((domain, index) => {
                                const status = getStatusBadge(domain.objectData.expiryDate, domain.objectData.autoRenew);
                                return (
                                    <tr key={domain.objectId} className="hover:bg-gray-50 transition-colors duration-150"
                                        style={{animationDelay: `${index * 100}ms`}}
                                    >
                                        <td className="px-6 py-4">
                                            <div className="flex items-center">
                                                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                                                    <i data-lucide="globe" className="w-5 h-5 text-blue-600"></i>
                                                </div>
                                                <span className="font-medium text-gray-900">{domain.objectData.domain}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-sm text-gray-700">
                                            {new Date(domain.objectData.expiryDate).toLocaleDateString()}
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full border ${status.class}`}>
                                                {status.text}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex space-x-2">
                                                <ActionButton icon="refresh-cw" label="Renew" variant="success" onClick={() => onAction('renew', domain)} />
                                                <ActionButton icon="zap" label={domain.objectData.autoRenew ? 'Manual' : 'Auto'} variant="primary" onClick={() => onAction('auto', domain)} />
                                                <ActionButton icon="download" label="Download" variant="secondary" onClick={() => onAction('download', domain)} />
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    } catch (error) {
        console.error('DomainTable component error:', error);
        reportError(error);
    }
}
