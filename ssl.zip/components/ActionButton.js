function ActionButton({ icon, label, onClick, variant = 'primary', size = 'sm', disabled = false }) {
    try {
        React.useEffect(() => {
            lucide.createIcons();
        }, []);

        const baseClasses = 'inline-flex items-center font-medium rounded-lg transition-all duration-200 transform hover:scale-105';
        const sizeClasses = size === 'sm' ? 'px-3 py-2 text-xs' : 'px-4 py-3 text-sm';
        
        const variantClasses = {
            primary: 'bg-blue-600 text-white hover:bg-blue-700 shadow-md hover:shadow-lg',
            secondary: 'bg-gray-100 text-gray-700 hover:bg-gray-200 shadow-sm hover:shadow-md',
            success: 'bg-green-600 text-white hover:bg-green-700 shadow-md hover:shadow-lg',
            warning: 'bg-yellow-600 text-white hover:bg-yellow-700 shadow-md hover:shadow-lg',
            danger: 'bg-red-600 text-white hover:bg-red-700 shadow-md hover:shadow-lg'
        };

        const disabledClasses = 'bg-gray-300 text-gray-500 cursor-not-allowed transform-none';

        return (
            <button
                onClick={onClick}
                disabled={disabled}
                className={`${baseClasses} ${sizeClasses} ${disabled ? disabledClasses : variantClasses[variant]}`}
                data-name="action-button"
                data-file="components/ActionButton.js"
            >
                <i data-lucide={icon} className="w-4 h-4 mr-1.5"></i>
                {label}
            </button>
        );
    } catch (error) {
        console.error('ActionButton component error:', error);
        reportError(error);
    }
}
