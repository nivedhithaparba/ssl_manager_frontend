function Notification({ notification, onClose }) {
    try {
        if (!notification) return null;

        React.useEffect(() => {
            lucide.createIcons();
        }, [notification]);

        const typeConfig = {
            success: {
                bg: 'bg-green-50 border-green-200',
                text: 'text-green-800',
                icon: 'check-circle'
            },
            error: {
                bg: 'bg-red-50 border-red-200',
                text: 'text-red-800',
                icon: 'x-circle'
            },
            info: {
                bg: 'bg-blue-50 border-blue-200',
                text: 'text-blue-800',
                icon: 'info'
            }
        };

        const config = typeConfig[notification.type] || typeConfig.info;

        return (
            <div className={`${config.bg} ${config.text} border rounded-xl p-4 mb-6 bounce-in flex items-center justify-between`}
                data-name="notification"
                data-file="components/Notification.js"
            >
                <div className="flex items-center">
                    <i data-lucide={config.icon} className="w-5 h-5 mr-3"></i>
                    <span className="font-medium">{notification.message}</span>
                </div>
                <button 
                    onClick={onClose}
                    className="ml-4 hover:opacity-70 transition-opacity"
                >
                    <i data-lucide="x" className="w-4 h-4"></i>
                </button>
            </div>
        );
    } catch (error) {
        console.error('Notification component error:', error);
        reportError(error);
    }
}
