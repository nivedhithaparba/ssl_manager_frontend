function LoadingSpinner({ size = 'md', color = 'blue' }) {
  try {
    const sizeClasses = {
      sm: 'w-4 h-4',
      md: 'w-6 h-6',
      lg: 'w-8 h-8'
    };

    const colorClasses = {
      blue: 'text-blue-600',
      white: 'text-white',
      gray: 'text-gray-600'
    };

    React.useEffect(() => {
      lucide.createIcons();
    }, []);

    return (
      <i 
        data-lucide="loader-2" 
        className={`${sizeClasses[size]} ${colorClasses[color]} animate-spin`}
      ></i>
    );
  } catch (error) {
    console.error('LoadingSpinner component error:', error);
    reportError(error);
  }
}
