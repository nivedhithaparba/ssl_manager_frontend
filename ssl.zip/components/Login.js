function Login({ onLogin, onToast }) {
    try {
        const [credentials, setCredentials] = React.useState({ username: '', password: '' });
        const [isLoading, setIsLoading] = React.useState(false);
        const [showPassword, setShowPassword] = React.useState(false);
        const [error, setError] = React.useState('');

        React.useEffect(() => {
            lucide.createIcons();
        }, []);

        const handleSubmit = async (e) => {
            e.preventDefault();
            setIsLoading(true);
            setError('');

            try {
                console.log('Login Request:', { username: credentials.username });
                
                const response = await apiService.login(credentials);
                
                console.log('Login Response:', response);
                
                if (response.success) {
                    authUtils.setAuthToken(response.token);
                    authUtils.setCurrentUser(response.user);
                    onLogin(response.user);
                    onToast('Login successful', 'success');
                } else {
                    throw new Error('Login failed');
                }
            } catch (err) {
                console.error('Login Error:', err);
                setError(err.message || 'Login failed');
                onToast('Login failed', 'error');
            } finally {
                setIsLoading(false);
            }
        };

        return (
            <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
                <div className="glass-bg rounded-2xl p-8 w-full max-w-md shadow-xl fade-in">
                    <div className="text-center mb-8">
                        <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i data-lucide="shield" className="w-8 h-8 text-white"></i>
                        </div>
                        <h1 className="text-2xl font-bold text-gray-900">SSL Dashboard</h1>
                        <p className="text-gray-600">Sign in to your account</p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
                            <input
                                type="text"
                                value={credentials.username}
                                onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                placeholder="Enter username"
                                required
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
                            <div className="relative">
                                <input
                                    type={showPassword ? 'text' : 'password'}
                                    value={credentials.password}
                                    onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-12"
                                    placeholder="Enter password"
                                    required
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                                >
                                    <i data-lucide={showPassword ? 'eye-off' : 'eye'} className="w-5 h-5"></i>
                                </button>
                            </div>
                        </div>

                        {error && (
                            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg bounce-in">
                                {error}
                            </div>
                        )}

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center"
                        >
                            {isLoading ? React.createElement(LoadingSpinner, { size: 'sm', color: 'white' }) : 'Sign In'}
                        </button>
                    </form>

                    <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-800 font-medium mb-2">Demo Credentials:</p>
                        <p className="text-xs text-blue-600">Admin: admin / admin123</p>
                        <p className="text-xs text-blue-600">User: user / user123</p>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('Login component error:', error);
        reportError(error);
    }
}
